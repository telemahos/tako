
jQuery(function($){

   $.supersized({

      // Functionality
      slideshow   :   0,      //Slideshow on/off

      // Components
      slides      :     [        // Slideshow Images
            {image : 'http://localhost/clients/tako/anders/img/hg.jpg', title : 'Image Credit: Maria Kazvan'}
            // {image : 'http://bootstrap4me.com/sandbox/anders/img/hg.jpg', title : 'Image Credit: Maria Kazvan'}

      ]
   });
});
